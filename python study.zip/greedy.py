# x,y = map(int, input().split())
# result = 0
# for i in range(y):
#     d = list(map(int, input().split()))
#     min_value = min(d)
#     result = max(min_value,result)
#
# print(result)

# n, r = map(int, input().split())
# count = 0
# while n != 1 :
#     count += 1
#     if n%r ==0:
#         n /= r
#     else:
#         n -= 1
# print(count)

# n = int(input())
# x,y = 1,1
# plans = input().split()
#
# dx = [0,0,-1,1]
# dy = [-1,1,0,0]
# move_types=['L','R','U','D']
#
# for plan in plans:
#     for i in range(len(move_types)):
#         if plan == move_types[i]:
#             nx = x + dx[i]
#             ny = y + dy[i]
#     if nx<1 or ny<1 or nx>n or ny> n:
#         continue
#     x,y = nx,ny
# print(x,y)

# 이건 뭔 쌉 고급 기술이냐
# h = int(input())
# count = 0
# for i in range(h+1):
#     for j in range(60):
#         for k in range(60):
#             if '3' in str(i) + str(j) + str(k):
#                 count+=1
# print(count)

# n = input()
# x, y = int(n[1]), ord(n[0])-97
# row = [-2,-2,-1,-1,1,1,2,2]
# col = [1,1,2,2,-2,-2,-1,-1]
# count =8
# for i in range(8):
#     if x + row[i] <0 or x + row[i]>8 or y +col[i] <0 or y +col[i] >8:
#         count-= 1
#
# print(count)

# 미완성
# x,y = map(int, input().split())
# dx, dy, c = map(int, input().split())
# count = 0
# d = []
# for i in range(x):
#     d.append(list(map(int,input().split())))
# row = [-1,0,1,0]
# col = [0,-1,0,1]
# while True:
#     count += 1
#     d[dx][dy] = 1
#     if d[dx+row[0]][dy+col[0]] and d[dx+row[1]][dy+col[1]] and d[dx+row[2]][dy+col[2]] and d[dx+row[3]][dy+col[3]] == 1:
#           break
#     c -= 1
#     if c == -1:
#         c = 3
#     if d[dx+row[c]][dy+col[c]] == 0 :
#         dx += row[c]
#         dy += col[c]
# for i in d:
#     print(i)
# print(count)

# dfs 천재새끼
# def dfs(graph,v,visited):
#     visited[v]=True
#     print(v,end=' ')
#     for i in graph[v]:
#         if not visited[i]:
#             dfs(graph,i,visited)
#
# graph = [[], [2,3,8],[1,7],[1,4,5],[3,5],[3,4],[7],[2,6,8],[1,7]]
#
# visited = [False]*9
# dfs(graph,1,visited)

from collections import deque
def bfs(graph, start, visited):
    queue = deque([start])
    visited[start] = True

    while queue:
        v=queue.popleft()
        print(v,end=' ')
        for i in graph[v]:
            if not visited[i]:
                queue.append(i)
                visited[i] = True

graph = [[],[2,3,8],[1,7],[1,4,5],[3,5],[3,4],[7],[2,6,8],[1,7]]
visited = [False]*9
bfs(graph,1,visited)

