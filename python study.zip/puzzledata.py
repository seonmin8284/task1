import pandas as pd
from pandas import DataFrame as df
from collections import Counter
import numpy as np
from datetime import datetime

r_d = pd.read_csv('C:\\repair_eng_ver2 (1).csv')

#크기
#print(r_d.shape)

#정보
#print(r_d.info())

# 정보 근데 거의 필요없을 듯
# print(r_d.describe())


# print(Counter(r_d['caseID']))
# print(r_d.columns)

# 다 겹치는 값이 있음
# for i in range(13):
#     if len(r_d[r_d.columns[i]]) == len(set(r_d[r_d.columns[i]])):
#         print("Unique")
#     else:
#         print("not unique")

# 1번 550, 2번 224개, 3번 94개, 4번 59
# print(r_d['RepairCode'].value_counts())


# 각 칼럼별 갯수 출력
# for i  in range(13):
#     print(r_d[r_d.columns[i]].value_counts())

# start 있는 칼럼만 출력
m=[]
# m = r_d[r_d['eventtype']=='start']
# print(m['taskID'].value_counts())

# phone 270 web 265 personal 240 letter 225
# m = r_d[-r_d['contact'].isna()]
# print(m['taskID'].value_counts())

# m = r_d[-r_d['RepairType'].isna()]
# print(m['RepairType'].value_counts())

# m = r_d[-r_d['RepairInternally'].isna()]
# print(m['taskID'].value_counts())

# m= r_d[r_d['originator']=='System']
# print(m['taskID'].value_counts())

# print(r_d['time'][range(5)])
#
r_d['time']=r_d['time'].astype(str)
for i in range(13262):
    r_d['time'][i]=r_d['time'][i].zfill(5)
rdata=r_d.sort_values(by=['caseID','date','time','eventtype','taskID'],ascending=True)

# print(rdata[rdata['caseID']==1])
# print(rdata.tail())
# rdata=rdata[rdata['eventtype']!='start']
# rdata=rdata[rdata['taskID']!='FirstContact']
# rdata=rdata[rdata['taskID']!='MakeTicket']
# rdata=rdata[rdata['taskID']!='ArrangeSurvey']
# rdata=rdata[rdata['taskID']!='InformClientSurvey']
# rdata=rdata[rdata['taskID']!='Survey']
# rdata=rdata[rdata['taskID']!='ImmediateRepair']
# rdata=rdata[rdata['taskID']!='InternRepair']
# rdata=rdata[rdata['taskID']!='RepairReady']
# rdata=rdata[rdata['taskID']!='ReadyInformClient']
# rdata=rdata[rdata['taskID']!='SendTicketToFinAdmin']
# print(rdata['taskID'].value_counts())

m=[]
# print(range(rdata['caseID']))
# for i in range(1,1000):
#     m.append(rdata[rdata['caseID']==i]['taskID'].iloc[0])
# dframe = df(data=m,columns=["colum1"])
# print(Counter(m))
# print(r_d.iloc[2])
#512 865

# print(rdata[rdata['caseID']==512])
# print(rdata[rdata['caseID']==865])
