import sys
# a= [2,4,0,5]
# a.append(6)
# #a.pop()
#
# a.pop(1)
# a.insert(1,10)
# a.remove(0)
# b=a.index(6)
# print(a)
# print(b)

def find_alphabet(dataset,alphabet):
    count = 0
    for data in dataset:
        for i in range(len(data)):
            if data[i]==alphabet:
                count += 1
    print(count)

a = 'hello'
print(a[1])