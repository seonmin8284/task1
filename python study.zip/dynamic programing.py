n,m=map(int,input().split())
x =n
d=[]
list = []
list.append(m)
for i in range(n):
    d.append(int(input()))
count = 0
d.sort()
n -= 1
def sunmin(m,n,d,count):
    # while True :
    #     if n < 0:
    #         return -1
    #     elif n == x:
    #         m += d[n]
    #         count -= 1
    #     else:
    #         if m%d[n] == 0:
    #             count += int(m/d[n])
    #             return count
    #         else :
    #             count += int(m/d[n])
    #             m = m - d[n]*int(m/d[n])
    #             if m < d[n]:
    #                 return sunmin(m,n-1,d,count)
    for j in range(n):
        for i in range(int(m/d[n])):
            m = m - d[n]*int(m/d[n])
            list.append(m)




count = sunmin(m,n,d,count)
if count == -1:
    print("답없음")
else :
    print(count)

# n,m = map(int, input().split())
# array = []
# for i in range(n):
#     array.append(int(input()))
#
# d = [10001] * (m+1)
# d[0] = 0
# for i in range(n):
#     for j in range(array[i],m+1):
#         if d[j-array[i]]!= 10001:
#             d[j] = min(d[j],d[j-array[i]]+1)
#
# if d[m] == 10001:
#     print(-1)
# else:
#     print(d[m])