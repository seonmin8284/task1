#"출력
#print('"Hello World"')
#\를 활용하여 기호 출력
#print("print(\"Hello\\nWorld\")")
#입력과 입력값을 int나 float 값으로 바꿔주기

#값을 각자 입력하고 띄어쓰기를 기준으로 분리되어 저장됨
# a,b=input().split()
# y,m,d=input().split('.')
# print(d,m,y,sep='-')

# a,b=input().split('-')
# print(a,b,sep='')

# 공백없애고 출력하는 방법2
# w1,w2=input().split()
# s=w1+w2
# print(s)

#16진수로 출력하기, 잘보면 '%X' 뒤에 쉼표가 없음
# a=input()
# n=int(a)
# print('%X'%n)

# 8진수 입력받기
# a=input()
# n=int(a,16)
# print('%o'%n)

#chr()은 정수->문자 ord()는 문자->정수
# n=int(input())
# print(chr(n))

# 다음문자 출력하기, 변환 필수
# n=ord(input())
# print(chr(n+1))

#숫자 변환
# a,b = input().split()
# c=int(a)-int(b)
# print(c)

#쉬어가기 : 변환하는게 중요. input하고 괄호넣기, 진수 바꾸는 거 외우기

# 문자열 * 정수는 여러번 반복한 문자열
# w,n=input().split()
# print(w*int(n))

# 몫 구하기
# a,b =input().split()
# c = int(a)//int(b)
# print(c)

# 나머지 구하기
# a,b=input().split()
# c=int(a)%int(b)
# print(c)

# 소숫점 n째 자리까지
# f=float(input())
# print(round(f,2))

# 이거는 그냥 소숫점에 0이 나오면 자름
# a, b=input().split()
# print(round(float(a)/float(b),3))

# 이거는 무조건 다 출력
# a, b=input().split()
# n=float(a)/float(b)
# print('%.3f'%n)

# 비트 옮기기
# a,b=map(int,input().split())
# print(a<<b)

#같지 않다
# a,b = map(int,input().split())
# print(a!=b)

#반대로 하기
# n=int(input())
# print(not(bool(n)))
# and or
# a,b = map(int,input().split())
# print(bool(a) or bool(b))
#보수
# a = int(input())
# print(~a)
#비트연산에서 xor은 ^
# a,b = map(int,input().split())
# print(a^b)

#3항 연산
# a,b,c=map(int,input().split())
# if a>=b :
#     if b>=c:
#         print(c)
#     else:
#         print(b)
# else:
#     if a>=c:
#         print(c)
#     else:
#         print(a)

# 짝수만 출력
# a,b,c=map(int,input().split())
# if a%2 == 0:
#     print(a)
# if b%2 == 0:
#     print(b)
# if c%2 == 0:
#     print(c)

# 계절 출력, 생각의 전환
# m = int(input())
# if m//3==1:
#     print("spring")
# else :
#     if m//3==2:
#         print("summer")
#     else:
#         if m//3 ==3:
#             print("fall")
#         else:
#             print("winter")

# 반복문
# n=1
# while n!=0:
#     n  = int(input())
#     if n!=0:
#         print(n)

# 마지막 줄 안 바꾸는 법과 글자를 숫자 변환법 복습
# n = ord(input())
# m = ord('a')
# while m<=n:
#     print(chr(m), end = ' ')
#     m+=1

#range 함수 기억하기
# n = int(input())
# for i in range(n+1):
#     print(i)

# 입력한 값까지 1,2,3... 더하기
# n = int(input())
# sum = 0
# count = 0
# while sum < n:
#     count+= 1
#     sum += count
# print(count)

# 2진수는 b이고, 8진수는 o 16진수는 x이다
# n = int(input(),16)
# for i in range(1,int('F',16)+1):
#     print('%X'%n,'*%X'%i,'=%X'%(n*i),sep='')

# 369 게임 생각해볼 수 있었던 건데
# n = int(input())
# for i in range(1,n+1):
#     if i%10 == 3 or i%10==6 or i%10==9:
#         print('X')
#     else :
#         print(i)

# 모르겠다 시발
# r,g,b = map(int,input().split())
# x=[]
# for l in range(r*g*b):
#     x.append([])
#     print(x,end=' ')
#     print(y,end=' ')
#     print(k,end=' ')
#     k+=1
#     if k == b:
#         y+=1
#         k=0
#     if y == g:
#         x+=1
#         y = 0
#     print()
#
# print(r*g*b)

# 복습
# a,b,c = map(int, input().split())
# mb= a*b*c/8/1024/1024
# print('%.2f'%mb,'MB')

# 줄 안바꾸는 거 연습
# n = int(input())
# for i in range(1,n+1):
#     if i%3 != 0:
#         print(i, end = ' ')

# **는 거듭제곱
# a,d,n = map(int,input().split())
# print(a*(d**(n-1)))

# 규칙적인 수식
# a,m,d,n=map(int,input().split())
# for i in range(n-1):
#     a = a*m+d
# print(a)

# 최소공배수 와 이거 개쩌네
# a,b,c = map(int, input().split())
# d = 1
# while d%a!=0 or d%b!=0 or d%c!=0:
#     d+=1
# print(d)

# 리스트로 저장, 배열 만들기
# n = int(input())
# a = input().split()
# d=[]
# for i in range(24):
#     d.append(0)
# for i in range(n):
#     a[i] = int(a[i])
#     d[a[i]]+=1
# for i in range(1,24):
#     print(d[i],end=' ')

# 리스트 활용 2
# n = int(input())
# a = input().split()
# for i in range(1,n+1):
#     a[n-i] = int(a[n-i])
#     print(a[n-i],end = ' ')

# 최소값 찾기
# n = int(input())
# a = input().split()
# for i in range(n):
#     a[i]=int(a[i])
# min = a[0]
# for i in range(n):
#     if a[i]<min:
#         min=a[i]
#
# print(min)

# 2차원 배열 만들기
# n = int(input())
# b = []
# for i in range(20):
#     b.append([])
#     for j in range(20):
#         b[i].append(0)
# for i in range(n):
#     x,y = map(int,input().split())
#     b[x][y]=1
# for i in range(1,20):
#     for j in range(1,20):
#        print(b[i][j],end=' ')
#     print()

# 쉬어가기
# 배열을 만들때는 a=[]를 써주고, 2차원 배열을 만들려면 a.append([])
# 빈 배열은 공간이 없음. 그래서 바로 할당하면 안되고 append로 채워줘야함

# 성공쓰
# d=[]
# for i in range(19):
#     d.append([])
#     d[i] = input().split()
#
# n = int(input())
# for i in range(n):
#     x, y = map(int, input().split())
#     for j in range(19):
#         if d[x-1][j] == '0':
#             d[x-1][j]= '1'
#         else:
#             d[x-1][j]='0'
#     for k in range(19):
#         if d[k][y-1] == '0':
#             d[k][y-1]= '1'
#         else:
#             d[k][y-1]='0'
#
# for i in range(19):
#     for j in range(19):
#         print(d[i][j],end= ' ')
#     print()

# 배열 다루기
# h,w = map(int,input().split())
# n = int(input())
# d = []
# for i in range(h):
#     d.append([])
#     for j in range(w):
#         d[i].append(0)
# for i in range(n):
#     l,m,x,y = map(int,input().split())
#
#     if m == 0:
#         for j in range(l):
#             d[x-1][y+j-1]=1
#     else:
#         for j in range(l):
#             d[x+j-1][y-1]=1
#
# for i in range(h):
#     for j in range(w):
#         print(d[i][j], end=' ')
#     print()

# 미로찾기
# d = []
# for i in range(10):
#     d.append([])
#     d[i]= input().split()
# x=1
# y=1
# while (d[x][y]!= '2' and (x!=8 or y!=8)):
#     d[x][y]='9'
#     if d[x][y+1]!='1':
#         y += 1
#     else:
#         x+=1
# d[x][y]='9'
#
# for i in range(10):
#     for j in range(10):
#         print(d[i][j],end=' ')
#     print()

# n,m,k = map(int, input().split())
# data = list(map(int,input().split()))
# sum = 0
# data.sort()
# for i in range(m):
#     if i%(k+1) == k :
#         sum+= data[-2]
#     else:
#         sum+=data[-1]
# print(sum)

# n = int(input())
# d =[]
# x, y = 0,0
# d = list(input().split())
# for i in d:
#     if i == 'R':
#         if y!=n-1:
#             y+=1
#     if i == 'L':
#         if y != 0:
#             y -= 1
#     if i == 'D':
#         if x != n-1:
#             x += 1
#     if i == 'U':
#         if x != 0:
#             x -= 1
# print(x+1,y+1)
# print(type(d))

# 디큐를 이용한 큐
# from collections import deque
# queue = deque()
# queue.append(5)
# queue.append(3)
# queue.append(4)
# queue.popleft()
# print(queue)
# queue.reverse()
# print(queue)

# 재귀함수 정의 및 호출
# def recursive_function():
#     return()
#     recursive_function()
#
# recursive_function()

