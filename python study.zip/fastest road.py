INF = int(1e9)

node, line = map(int, input().split())
visited = [] * (node+1)
distance = [INF] * (node+1)
start = int(input())
graph = [[] for i in range(node+1)]

for i in range(line):
    a,b,c = map(int, input().split())
    graph[a].append((b,c))

for